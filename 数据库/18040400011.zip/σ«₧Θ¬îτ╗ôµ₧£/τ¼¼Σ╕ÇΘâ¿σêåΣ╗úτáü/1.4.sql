use master;

select DISTINCT sno
from sc
where cno = 'CS3121014' or 'CS3221018'