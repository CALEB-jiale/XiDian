use master;

select sno,count(cno)
from sc
where grade > 90 and sno in
(
	select sno
	from sc
	where grade > 92
	group by sno
	having count(distinct cno) > 4
)
group by sno
