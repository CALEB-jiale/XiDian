use master;

select sno,sname
from student s
where not exists
(
	select *
    from sc sc1
    where sno = '03051066' and not exists
    (
		select *
        from sc sc2
        where sc1.cno = sc2.cno and s.sno = sc2.sno
    )
)