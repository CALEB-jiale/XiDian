use master;

select sum(ccredit)
from course,sc
where sno = '3051014' and course.cno = sc.cno