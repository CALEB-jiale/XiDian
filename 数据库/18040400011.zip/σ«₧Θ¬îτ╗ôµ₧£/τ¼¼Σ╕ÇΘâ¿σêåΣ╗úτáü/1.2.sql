use master;

select s.sno,sname
from sc
join student s
	on sc.sno=s.sno
where cno = 'CS3121014'