use master;

select max(grade)
from sc
where cno = 'CS3121014'