use master;

select sname,sno,ssex
from student
where sname like '刘%'