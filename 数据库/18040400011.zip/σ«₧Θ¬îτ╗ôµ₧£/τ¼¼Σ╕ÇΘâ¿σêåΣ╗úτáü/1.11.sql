use master;

select sname,sno
from student
where sname like '_阳%'