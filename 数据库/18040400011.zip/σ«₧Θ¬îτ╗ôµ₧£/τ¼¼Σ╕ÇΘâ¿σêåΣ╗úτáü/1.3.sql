use master;

select s.sno,sname,grade
from sc
join student s
	on sc.sno=s.sno
join course c
	on sc.cno=c.cno
where cname = '数据库系统'
order by grade desc