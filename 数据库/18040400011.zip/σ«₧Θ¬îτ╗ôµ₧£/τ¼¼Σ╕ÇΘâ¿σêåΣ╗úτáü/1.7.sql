use master;

select cpno
from pcourse
where cno = 'CS3121014'