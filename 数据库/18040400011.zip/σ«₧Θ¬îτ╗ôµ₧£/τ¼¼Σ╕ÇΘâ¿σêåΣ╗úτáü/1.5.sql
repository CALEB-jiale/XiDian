use master;

select s1.sno
from sc s1, sc s2
where s1.sno = s2.sno and s1.cno = 'CS3121014' and s2.cno = 'CS3221018'
