use master;

select sno
from sc
where sno not in
(
	select sno
    from sc
    where cno = 'CS3121014'
)