use master;

select sno,grade
from sc
where cno = 'CS3121014'