use master;

select sno
from sc
group by sno
having count(cno) > 3