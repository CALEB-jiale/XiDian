use master;

select count(distinct sno)
from sc