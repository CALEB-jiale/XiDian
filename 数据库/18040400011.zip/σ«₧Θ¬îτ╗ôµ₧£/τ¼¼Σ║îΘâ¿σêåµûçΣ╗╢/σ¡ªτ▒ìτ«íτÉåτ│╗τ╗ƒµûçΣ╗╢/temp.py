# -*- coding: utf-8 -*-
import pymysql
from flask import Flask, request, jsonify
from flask_cors import CORS

#数据库连接
db = pymysql.connect("127.0.0.1","root","ye123456","stumanage")
cursor = db.cursor()

#后端服务启动
app = Flask(__name__)
CORS(app, resources=r'/*')







@app.route('/login/list', methods=['POST'])
def login_list():
    if request.method == "POST":
        cursor.execute("select id,username,role from login")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["username"]=i[1]
                temp["role"]=i[2]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/login/add', methods=['POST'])
def login_add():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        role = request.form.get("role")
        try:
            cursor.execute("insert into login(username,password,role) values (\""
                            +str(username)+"\",\""+str(password)+"\",\""+
                            str(role)+"\")")
            db.commit() #提交，使操作生效
            print("add a new user successfully!")
            return "1"
        except Exception as e:
            print("add a new user failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/login/login', methods=['POST'])
def login_login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        cursor.execute("select id,username,role from login where username=\""
                       +str(username)+"\" and password=\""+str(password)+"\"")
        data = cursor.fetchone()
        if(data!=None):
            print("result:",data)
            jsondata = {"id":str(data[0]),"username":str(data[1]),
                        "role":str(data[2])}
            return jsonify(jsondata)
        else:
            print("result: NULL")
            jsondata = {}
            return jsonify(jsondata)

@app.route('/login/update', methods=['POST'])
def login_update():
    if request.method == "POST":
        id = request.form.get("id")
        password = request.form.get("password")
        try:
            cursor.execute("update login set password=\""+str(password)
                            +"\" where id="+str(id))
            db.commit()
            print("update password successfully!")
            return "1"
        except Exception as e:
            print("update password failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/login/update_role', methods=['POST'])
def login_update_role():
    if request.method == "POST":
        id = request.form.get("id")
        role = request.form.get("role")
        try:
            cursor.execute("update login set role=\""+str(role)
                            +"\" where id="+str(id))
            db.commit()
            print("update role successfully!")
            return "1"
        except Exception as e:
            print("update role failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/login/del', methods=['POST'])
def login_del():
    if request.method == "POST":
        id = request.form.get("id")
        try:
            cursor.execute("delete from login where id="+str(id))
            db.commit()
            print("delete user "+str(id)+" successfully!")
            return "1"
        except Exception as e:
            print("delete the user failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"










@app.route('/student/list', methods=['POST'])
def student_list():
    if request.method == "POST":
        cursor.execute("select * from student")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/student/list1', methods=['POST'])
def student_list1():
    if request.method == "POST":
        cursor.execute("select id,sno,sname,sex,school,major,sclass,date from student where sno in "
                       +"(select sno from sc join course on course.cno=sc.cno where grade<60 and exam>0 and feature=\"必修课\" group by sno having sum(credit)>28 "
                       +"union select sno from sc join course on course.cno=sc.cno where grade<60 and exam>0 and feature=\"必修课\" group by sno,semester having sum(credit)>8"
                       +" union select sno from sc join course on course.cno=sc.cno where grade<60 and exam>0 and feature=\"选修课\" group by sno having sum(credit)>18)")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/student/add', methods=['POST'])
def student_add():
    if request.method == "POST":
        sno = request.form.get("sno")
        sname = request.form.get("sname")
        sex = request.form.get("sex")
        school = request.form.get("school")
        major = request.form.get("major")
        sclass = request.form.get("sclass")
        date = request.form.get("date")
        try:
            cursor.execute("insert into student(sno,sname,sex,school,major,sclass,date)"
                           +"values (\""+str(sno)+"\",\""+str(sname)+"\",\""+str(sex)+"\",\""+str(school)+"\",\""+str(major)+"\",\""+str(sclass)+"\",\""+str(date)+"\")")
            db.commit() #提交，使操作生效
            print("add a new message successfully!")
            return "1"
        except Exception as e:
            print("add a new message failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/student/del', methods=['POST'])
def student_del():
    if request.method == "POST":
        id = request.form.get("id")
        try:
            cursor.execute("delete from student where id="+str(id))
            db.commit()
            print("delete student "+str(id)+" successfully!")
            return "1"
        except Exception as e:
            print("delete the student failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/student/update_sname', methods=['POST'])
def student_update_sname():
    if request.method == "POST":
        id = request.form.get("id")
        sname = request.form.get("sname")
        try:
            cursor.execute("update student set sname=\""+str(sname)+"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/student/update', methods=['POST'])
def student_update():
    if request.method == "POST":
        id = request.form.get("id")
        sname = request.form.get("sname")
        school = request.form.get("school")
        major = request.form.get("major")
        sclass = request.form.get("sclass")
        date = request.form.get("date")
        try:
            cursor.execute("update student set date=\""+str(date)+"\",sname=\""+str(sname)
                           +"\",school=\""+str(school)+"\", major=\""+str(major)
                           +"\",sclass=\""+str(sclass)+"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/student/loc_sno', methods=['POST'])
def student_loc_sno():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select * from student where sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/student/loc_sname', methods=['POST'])
def student_loc_sname():
    if request.method == "POST":
        sname = request.form.get("sname")
        cursor.execute("select * from student where sname=\""+str(sname)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/student/loc_school', methods=['POST'])
def student_loc_school():
    if request.method == "POST":
        school = request.form.get("school")
        cursor.execute("select * from student where school=\""+str(school)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/student/loc_major', methods=['POST'])
def student_loc_major():
    if request.method == "POST":
        major = request.form.get("major")
        cursor.execute("select * from student where major=\""+str(major)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/student/loc_sclass', methods=['POST'])
def student_loc_sclass():
    if request.method == "POST":
        sclass = request.form.get("sclass")
        cursor.execute("select * from student where sclass=\""+str(sclass)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["sname"]=i[2]
                temp["sex"]=i[3]
                temp["school"]=i[4]
                temp["major"]=i[5]
                temp["sclass"]=i[6]
                temp["date"]=i[7]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])








@app.route('/course/list', methods=['POST'])
def course_list():
    if request.method == "POST":
        cursor.execute("select * from course")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["semester"]=i[4]
                temp["feature"]=i[5]
                temp["tname"]=i[6]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/course/add', methods=['POST'])
def course_add():
    if request.method == "POST":
        cno = request.form.get("cno")
        cname = request.form.get("cname")
        credit = request.form.get("credit")
        semester = request.form.get("semester")
        feature = request.form.get("feature")
        tname = request.form.get("tname")
        try:
            cursor.execute("insert into course(cname,cno,credit,semester,feature,tname)"
                           +"values (\""+str(cname)+"\",\""+str(cno)+"\",\""+str(credit)+"\",\""+str(semester)+"\",\""+str(feature)+"\",\""+str(tname)+"\")")
            db.commit() #提交，使操作生效
            print("add a new message successfully!")
            return "1"
        except Exception as e:
            print("add a new message failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/course/del', methods=['POST'])
def course_del():
    if request.method == "POST":
        id = request.form.get("id")
        try:
            cursor.execute("delete from course where id="+str(id))
            db.commit()
            print("delete course "+str(id)+" successfully!")
            return "1"
        except Exception as e:
            print("delete the course failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/course/update_cname', methods=['POST'])
def course_update_cname():
    if request.method == "POST":
        id = request.form.get("id")
        cname = request.form.get("cname")
        try:
            cursor.execute("update course set cname=\""+str(cname) 
                           +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/course/update_credit', methods=['POST'])
def course_update_credit():
    if request.method == "POST":
        id = request.form.get("id")
        credit = request.form.get("credit")
        try:
            cursor.execute("update course set credit=\""+str(credit)
                           +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/course/update_feature', methods=['POST'])
def course_update_feature():
    if request.method == "POST":
        id = request.form.get("id")
        feature = request.form.get("feature")
        try:
            cursor.execute("update course set feature=\""+str(feature)
                           +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/course/update_tname', methods=['POST'])
def course_update_tname():
    if request.method == "POST":
        id = request.form.get("id")
        tname = request.form.get("tname")
        try:
            cursor.execute("update course set tname=\""+str(tname)
                            +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/course/update', methods=['POST'])
def course_update():
    if request.method == "POST":
        id = request.form.get("id")
        cno = request.form.get("cno")
        cname = request.form.get("cname")
        credit = request.form.get("credit")
        semester = request.form.get("semester")
        feature = request.form.get("feature")
        tname = request.form.get("tname")
        try:
            cursor.execute("update course set cno=\""+str(cno) +"\",cname=\""+str(cname) +"\",credit=\""
                           +str(credit)+"\",semester=\""+str(semester) +"\",feature=\""+str(feature)
                           +"\",tname=\""+str(tname)+"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/course/loc_cname', methods=['POST'])
def course_loc_cname():
    if request.method == "POST":
        cname = request.form.get("cname")
        cursor.execute("select * from course where cname=\""+str(cname)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["feature"]=i[4]
                temp["tname"]=i[5]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/course/loc_cno', methods=['POST'])
def course_loc_cno():
    if request.method == "POST":
        cno = request.form.get("cno")
        cursor.execute("select * from course where cno=\""+str(cno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["feature"]=i[4]
                temp["tname"]=i[5]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/course/loc_tname', methods=['POST'])
def course_loc_tname():
    if request.method == "POST":
        tname = request.form.get("tname")
        cursor.execute("select * from course where tname=\""+str(tname)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["feature"]=i[4]
                temp["tname"]=i[5]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/course/loc_semester', methods=['POST'])
def course_loc_semester():
    if request.method == "POST":
        semester = request.form.get("semester")
        cursor.execute("select * from course where semester=\""+str(semester)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["feature"]=i[4]
                temp["tname"]=i[5]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/course/loc_feature', methods=['POST'])
def course_loc_feature():
    if request.method == "POST":
        feature = request.form.get("feature")
        cursor.execute("select * from course where feature=\""+str(feature)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["cno"]=i[1]
                temp["cname"]=i[2]
                temp["credit"]=i[3]
                temp["feature"]=i[4]
                temp["tname"]=i[5]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])












@app.route('/sc/list', methods=['POST'])
def sc_list():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/loc_cname', methods=['POST'])
def sc_loc_cname():
    if request.method == "POST":
        cname = request.form.get("cname")
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where"
                       +" cname=\""+str(cname)+"\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/loc_cno', methods=['POST'])
def sc_loc_cno():
    if request.method == "POST":
        cno = request.form.get("cno")
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where"
                       +" sc.cno=\""+str(cno)+"\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/loc_semester', methods=['POST'])
def sc_loc_semester():
    if request.method == "POST":
        semester = request.form.get("semester")
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where"
                       +" semester=\""+str(semester)+"\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/loc_feature', methods=['POST'])
def sc_loc_feature():
    if request.method == "POST":
        feature = request.form.get("feature")
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where"
                       +" feature=\""+str(feature)+"\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/loc_tname', methods=['POST'])
def sc_loc_tname():
    if request.method == "POST":
        tname = request.form.get("tname")
        sno = request.form.get("sno")
        cursor.execute("select sc.id,sno,cname,grade,sc.cno,credit,semester,feature,tname,exam from sc join course on course.cno=sc.cno where"
                       +" tname=\""+str(tname)+"\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cname"]=i[2]
                temp["grade"]=i[3]
                temp["cno"]=i[4]
                temp["credit"]=i[5]
                temp["semester"]=i[6]
                temp["feature"]=i[7]
                temp["tname"]=i[8]
                temp["exam"]=i[9]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/sc/add', methods=['POST'])
def sc_add():
    if request.method == "POST":
        sno = request.form.get("sno")
        cno = request.form.get("cno")
        exam = request.form.get("exam")
        grade = request.form.get("grade")
        try:
            cursor.execute("insert into sc(sno,cno,exam,grade)"
                           +"values (\""+str(sno)+"\",\""+str(cno)+"\",\""+str(exam)+"\",\""+str(grade)+"\")")
            db.commit() #提交，使操作生效
            print("add a new message successfully!")
            return "1"
        except Exception as e:
            print("add a new message failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/sc/del', methods=['POST'])
def sc_del():
    if request.method == "POST":
        id = request.form.get("id")
        try:
            cursor.execute("delete from sc where id="+str(id))
            db.commit()
            print("delete sc "+str(id)+" successfully!")
            return "1"
        except Exception as e:
            print("delete the message failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/sc/update_sno', methods=['POST'])
def sc_update_sno():
    if request.method == "POST":
        id = request.form.get("id")
        sno = request.form.get("sno")
        try:
            cursor.execute("update sc set sno=\""+str(sno)
                            +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"

@app.route('/sc/update_cno', methods=['POST'])
def sc_update_cno():
    if request.method == "POST":
        id = request.form.get("id")
        cno = request.form.get("cno")
        try:
            cursor.execute("update sc set cno=\""+str(cno)
                            +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/sc/update_exam', methods=['POST'])
def sc_update_exam():
    if request.method == "POST":
        id = request.form.get("id")
        exam = request.form.get("exam")
        try:
            cursor.execute("update sc set exam=\""+str(exam)
                            +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/sc/update_grade', methods=['POST'])
def sc_update_grade():
    if request.method == "POST":
        id = request.form.get("id")
        grade = request.form.get("grade")
        try:
            cursor.execute("update sc set grade=\""+str(grade)
                            +"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/sc/update_exam_grade', methods=['POST'])
def sc_update_exam_grade():
    if request.method == "POST":
        id = request.form.get("id")
        cno = request.form.get("cno")
        exam = request.form.get("exam")
        grade = request.form.get("grade")
        try:
            cursor.execute("update sc set grade=\""+str(grade)+"\",exam=\""
                           +str(exam)+"\",cno=\""+str(cno)+"\" where id="+str(id))
            db.commit()
            print("update successfully!")
            return "1"
        except Exception as e:
            print("update failed:",e)
            db.rollback() #发生错误就回滚
            return "-1"
        
@app.route('/sc/loc_sno', methods=['POST'])
def sc_loc_sno():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select * from sc where sno=\""+str(sno)+"\"")
        data = cursor.fetchall()
        temp={}
        result=[]
        if(data!=None):
            for i in data:
                temp["id"]=i[0]
                temp["sno"]=i[1]
                temp["cno"]=i[2]
                temp["exam"]=i[3]
                temp["grade"]=i[4]
                result.append(temp.copy()) #特别注意要用copy，否则只是内存的引用
            print("result:",len(data))
            return jsonify(result)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/sc/average', methods=['POST'])
def sc_average():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select avg(grade) from sc where exam>0 and sno=\""+str(sno)+"\"")
        data = cursor.fetchone()
        if(data!=None):
            print("result:",data)
            jsondata = {"average":str(data[0])}
            return jsonify(jsondata)
        else:
            print("result: NULL")
            return jsonify([])
        
@app.route('/sc/average1', methods=['POST'])
def sc_average1():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select avg(grade) from sc join course on course.cno=sc.cno where exam>0 and feature=\"必修课\" and sno=\""+str(sno)+"\"")
        data = cursor.fetchone()
        if(data!=None):
            print("result:",data)
            jsondata = {"average1":str(data[0])}
            return jsonify(jsondata)
        else:
            print("result: NULL")
            return jsonify([])

@app.route('/sc/sum', methods=['POST'])
def sc_sum():
    if request.method == "POST":
        sno = request.form.get("sno")
        cursor.execute("select sum(credit) from sc join course on course.cno=sc.cno where grade>60 and sno=\""+str(sno)+"\"")
        data = cursor.fetchone()
        if(data!=None):
            print("result:",data)
            jsondata = {"sum":str(data[0])}
            return jsonify(jsondata)
        else:
            print("result: NULL")
            return jsonify([])


if __name__ == "__main__":
    app.run(host='0.0.0.0',port=9090)
    db.close()
    print("Good bye!")
