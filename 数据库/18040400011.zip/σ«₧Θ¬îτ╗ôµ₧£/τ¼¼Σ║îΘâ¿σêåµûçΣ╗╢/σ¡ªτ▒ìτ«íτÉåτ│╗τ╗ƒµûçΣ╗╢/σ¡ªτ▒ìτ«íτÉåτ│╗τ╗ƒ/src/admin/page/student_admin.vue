<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-setting"></i> 管理</el-breadcrumb-item>
                <el-breadcrumb-item>学生信息</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div>请选择查询的方式:</div>
        <el-button type="text" @click="loc_sno()" >学号</el-button>
        <el-button type="text" @click="loc_sname()" >姓名</el-button>
        <el-button type="text" @click="loc_school()" >学院</el-button>
        <el-button type="text" @click="loc_major()" >专业</el-button>
        <el-button type="text" @click="loc_sclass()" >班级</el-button>
        <el-button type="text" @click="init()" >全部学生</el-button>
        <div>
            <el-button type="primary" @click="addmessage()" align="center">添加学生信息</el-button>
            <el-button type="primary" @click="droplist()" align="center">退学警告</el-button>
        </div>
        <div>
            <el-table :data="data" border style="width: 90%" ref="multipleTable" >
                <el-table-column label="ID" prop="id" width="80px" ></el-table-column>
                <el-table-column label="学号" prop="sno" width="120px" ></el-table-column>
                <el-table-column label="姓名" prop="sname" width="100px" ></el-table-column>
                <el-table-column label="性别" prop="sex" width="80px" ></el-table-column>
                <el-table-column label="学院" prop="school" width="200px" ></el-table-column>
                <el-table-column label="专业" prop="major" width="200px" ></el-table-column>
                <el-table-column label="班级" prop="sclass" width="100px" ></el-table-column>
                <el-table-column label="出生日期" prop="date" width="100px" ></el-table-column>
                <el-table-column label="操作" width="230px" >
                    <template slot-scope="scope" width="100px">
                        <el-button type="text" @click="gotourl(scope.row)" >成绩查询</el-button>
                        <el-button type="text" @click="openedit(scope.row)" >修改</el-button>
                        <el-button type="text" @click="del_stu(scope.row)" >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <el-dialog
            width="30%"
            title="修改"
            :visible.sync="dialogFormVisibleed">
            <div>
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="姓名" prop="sname">
                        <el-input v-model="form.sname" placeholder="请输入学生姓名"></el-input>
                    </el-form-item>

                    <el-form-item label="学院" prop="school">
                        <el-input v-model="form.school" placeholder="请输入转入学院"></el-input>
                    </el-form-item>

                    <el-form-item label="专业" prop="major">
                        <el-input v-model="form.major" placeholder="请输入转入专业"></el-input>
                    </el-form-item>

                    <el-form-item label="班级" prop="sclass">
                        <el-input v-model="form.sclass" placeholder="请输入转入班级"></el-input>
                    </el-form-item>

                    <el-form-item label="出生日期" prop="date">
                        <el-input v-model="form.date" placeholder="请输入出生日期"></el-input>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed = false" >取消</el-button>
                        <el-button type="primary" @click="submit('form')">修改</el-button>
                    </el-form-item>

                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="添加信息"
            :visible.sync="dialogFormVisibleed1">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="学号" prop="sno">
                        <el-input v-model="form.sno" placeholder="请输入学号"></el-input>
                    </el-form-item>

                    <el-form-item label="姓名" prop="sname">
                        <el-input v-model="form.sname" placeholder="请输入姓名"></el-input>
                    </el-form-item>

                    <el-form-item label="性别" prop="sex">
                        <el-select v-model="form.sex" placeholder="请设置性别">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="学院" prop="school">
                        <el-input v-model="form.school" placeholder="请输入学院"></el-input>
                    </el-form-item>

                    <el-form-item label="专业" prop="major">
                        <el-input v-model="form.major" placeholder="请输入专业"></el-input>
                    </el-form-item>

                    <el-form-item label="班级" prop="sclass">
                        <el-input v-model="form.sclass" placeholder="请输入班级"></el-input>
                    </el-form-item>

                    <el-form-item label="出生日期" prop="date">
                        <el-input v-model="form.date" placeholder="请输入出生日期"></el-input>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed1 = false" >取消</el-button>
                        <el-button type="primary" @click="addnew(form)">添加</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed2">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="学号" prop="sno">
                        <el-input v-model="form.sno" placeholder="请输入需要查询的学号"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed2 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_sno_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed3">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="姓名" prop="sname">
                        <el-input v-model="form.sname" placeholder="请输入需要查询的姓名"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed3 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_sname_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed4">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="学院" prop="school">
                        <el-input v-model="form.school" placeholder="请输入需要查询的学院"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed4 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_school_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed5">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="专业" prop="major">
                        <el-input v-model="form.major" placeholder="请输入需要查询的专业"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed5 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_major_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed6">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="班级" prop="sclass">
                        <el-input v-model="form.sclass" placeholder="请输入需要查询的班级"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed6 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_sclass_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

    </div>
</template>

<script>
    import main from "../../main";
    export default {
        data: function(){
            return {
                data:[],
                options:[{value: "男", label: "男"},{value: "女", label: "女"}],
                dialogFormVisibleed:false,
                dialogFormVisibleed1:false,
                dialogFormVisibleed2:false,
                dialogFormVisibleed3:false,
                dialogFormVisibleed4:false,
                dialogFormVisibleed5:false,
                dialogFormVisibleed6:false,
                form:{
                    id: '',
                    sno:'',
                    sname:'',
                    sex:'',
                    school:'',
                    major:'',
                    sclass:'',
                    date:''
                },
                rules:{
                    sno:[
                        {required:true,message:'请输入学号',trigger:'blur'}
                    ],
                    sname:[
                        {required:true,message:'请输入姓名',trigger:'blur'}
                    ],
                    sex:[
                        {required:true,message:'请设置性别',trigger:'blur'}
                    ],
                    school:[
                        {required:true,message:'请输入学院',trigger:'blur'}
                    ],
                    major:[
                        {required:true,message:'请输入专业',trigger:'blur'}
                    ],
                    sclass:[
                        {required:true,message:'请输入班级',trigger:'blur'}
                    ],
                    date:[
                        {required:true,message:'请输入出生日期',trigger:'blur'}
                    ]
                }
            }
        },
        created(){
            if(localStorage.getItem('username')===""){
                this.$router.replace('/login')
            }else{this.init();}
        },
        methods:{
            init(){
                this.$http.post(main.url+"/student/list",
                    {},
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                );
            },
            droplist(){
                this.$http.post(main.url+"/student/list1",
                    {},
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                );
            },
            gotourl(row){ //进入成绩页面
                localStorage.setItem('sno',row.sno);
                localStorage.setItem('sname',row.sname);
                this.$router.push('/grades')
            },
            loc_sno(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed2=true;
                this.form={
                    sno :''
                };
            },
            loc_sno_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/student/loc_sno",
                    {
                        'sno': this.form.sno
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed2=false;
            },
            loc_sname(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed3=true;
                this.form={
                    sname :''
                };
            },
            loc_sname_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/student/loc_sname",
                    {
                        'sname': this.form.sname
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed3=false;
            },
            loc_school(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed4=true;
                this.form={
                    school :''
                };
            },
            loc_school_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/student/loc_school",
                    {
                        'school': this.form.school
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed4=false;
            },
            loc_major(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed5=true;
                this.form={
                    major :''
                };
            },
            loc_major_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/student/loc_major",
                    {
                        'major': this.form.major
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed5=false;
            },
            loc_sclass(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed6=true;
                this.form={
                    sclass :''
                };
            },
            loc_sclass_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/student/loc_sclass",
                    {
                        'sclass': this.form.sclass
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed6=false;
            },
            openedit(row){ //修改学生信息，按钮按下后
                this.dialogFormVisibleed=true;
                this.form={
                    id: row.id,
                    sname: row.sname,
                    school: row.school,
                    major: row.major,
                    sclass: row.sclass,
                    date: row.date
                };
            },
            submit(form){ //修改，提交
                this.$http.post(main.url+"/student/update",
                    {
                        'id': this.form.id,
                        'sname': this.form.sname,
                        'school': this.form.school,
                        'major': this.form.major,
                        'sclass': this.form.sclass,
                        'date': this.form.date
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=> {
                        this.$message({type: 'success', message: '修改成功'});
                        this.form={
                            id: '',
                            sname: '',
                            school:'',
                            major:'',
                            sclass:'',
                            date:''
                        };
                        this.dialogFormVisibleed = false;
                        this.init();
                    }
                )
            },
            addmessage(){this.dialogFormVisibleed1=true},
            addnew(form){ //添加学生信息
                if(this.form.sno==="")
                    this.$message({type: 'error', message: '学号不能为空！'});
                else if(this.form.sname==="")
                    this.$message({type: 'error', message: '姓名不能为空！'});
                else if(this.form.sex==="")
                    this.$message({type: 'error', message: '性别不能为空！'});
                else if(this.form.school==="")
                    this.$message({type: 'error', message: '学院不能为空！'});
                else if(this.form.major==="")
                    this.$message({type: 'error', message: '专业不能为空！'});
                else if(this.form.sclass==="")
                    this.$message({type: 'error', message: '班级不能为空！'});
                else if(this.form.date==="")
                    this.$message({type: 'error', message: '出生日期不能为空！'});
                else{
                    this.$http.post(main.url+"/student/add",
                        {
                            'sno': this.form.sno,
                            'sname': this.form.sname,
                            'sex': this.form.sex,
                            'school': this.form.school,
                            'major': this.form.major,
                            'sclass': this.form.sclass,
                            'date': this.form.date
                        },
                        {
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            emulateJSON: true
                        }).then(
                        success => {
                            this.$message({type: 'success', message: '添加成功'});
                            this.form = {
                                sno: '',
                                sname:'',
                                sex:'',
                                school:'',
                                major:'',
                                sclass:'',
                                date:''
                            };
                            this.init();
                        }
                    );
                    this.dialogFormVisibleed1 = false;
                }
            },
            del_stu(row){ //删除学生信息
                this.$confirm('请确认是否要删除该学生信息！', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.post(main.url+"/student/del",
                        {'id': row.id,},
                        {
                            headers: {'Content-Type':'application/x-www-form-urlencoded'},
                            emulateJSON: true
                        }).then(
                        success=> {
                            this.$message({type: 'success', message: '已删除'});
                            this.init();
                        }
                    );
                }).catch(() => {
                    this.$message({type: 'info', message: '已取消'});
                });
            },
        }
    }
</script>
