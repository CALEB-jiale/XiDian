<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-setting"></i> 管理</el-breadcrumb-item>
                <el-breadcrumb-item>课程</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div>请选择查询的方式:</div>
        <el-button type="text" @click="loc_cno()" >课程号</el-button>
        <el-button type="text" @click="loc_cname()" >课程名</el-button>
        <el-button type="text" @click="loc_semester()" >学期</el-button>
        <el-button type="text" @click="loc_feature()" >课程属性</el-button>
        <el-button type="text" @click="loc_tname()" >任课老师</el-button>
        <el-button type="text" @click="init()" >全部课程</el-button>
        <div>
            <el-button type="primary" @click="addmessage()" align="center">添加课程</el-button>
            </div>
        <div>
            <el-table :data="data" border style="width: 90%" ref="multipleTable" >
                <el-table-column label="id" prop="id" width="80px" ></el-table-column>
                <el-table-column label="课程号" prop="cno" width="120px" ></el-table-column>
                <el-table-column label="课程名" prop="cname" width="360px" ></el-table-column>
                <el-table-column label="学分" prop="credit" width="80px" ></el-table-column>
                <el-table-column label="学期" prop="semester" width="80px" ></el-table-column>
                <el-table-column label="课程属性" prop="feature" width="100px" ></el-table-column>
                <el-table-column label="任课老师" prop="tname" width="100px" ></el-table-column>
                <el-table-column label="操作" width="290px" >
                    <template slot-scope="scope" width="100px">
                        <el-button type="text" @click="openedit(scope.row)" >修改</el-button>
                        <el-button type="text" @click="del_stu(scope.row)" >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <el-dialog
            width="30%"
            title="修改"
            :visible.sync="dialogFormVisibleed">
            <div>
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="课程号" prop="cno">
                        <el-input v-model="form.cno" placeholder="请输入课程号"></el-input>
                    </el-form-item>

                    <el-form-item label="课程名" prop="cname">
                        <el-input v-model="form.cname" placeholder="请输入课程名"></el-input>
                    </el-form-item>

                    <el-form-item label="学分" prop="credit">
                        <el-input v-model="form.credit" placeholder="请输入学分"></el-input>
                    </el-form-item>

                    <el-form-item label="学期" prop="semester">
                        <el-select v-model="form.semester" placeholder="请设置学期">
                            <el-option
                                v-for="item in options1"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="课程属性" prop="feature">
                        <el-select v-model="form.feature" placeholder="请设置课程属性">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="任课老师" prop="tname">
                        <el-input v-model="form.tname" placeholder="请输入任课老师姓名"></el-input>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed = false" >取消</el-button>
                        <el-button type="primary" @click="submit('form')">修改</el-button>
                    </el-form-item>

                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="添加信息"
            :visible.sync="dialogFormVisibleed1">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="课程号" prop="cno">
                        <el-input v-model="form.cno" placeholder="请输入课程号"></el-input>
                    </el-form-item>

                    <el-form-item label="课程名" prop="cname">
                        <el-input v-model="form.cname" placeholder="请输入课程名"></el-input>
                    </el-form-item>

                    <el-form-item label="学分" prop="credit">
                        <el-input v-model="form.credit" placeholder="请输入学分"></el-input>
                    </el-form-item>

                    <el-form-item label="学期" prop="semester">
                        <el-select v-model="form.semester" placeholder="请选择学期">
                            <el-option
                                v-for="item in options1"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="课程属性" prop="feature">
                        <el-select v-model="form.feature" placeholder="请设置课程属性">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="任课老师" prop="tname">
                        <el-input v-model="form.tname" placeholder="请输入任课老师姓名"></el-input>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed1 = false" >取消</el-button>
                        <el-button type="primary" @click="addnew(form)">添加</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed2">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="课程名" prop="cname">
                        <el-input v-model="form.cname" placeholder="请输入需要查询的课程名"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed2 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_cname_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed6">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="课程号" prop="cno">
                        <el-input v-model="form.cno" placeholder="请输入需要查询的课程号"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed2 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_cno_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed3">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="学期" prop="semester">
                        <el-select v-model="form.semester" placeholder="请选择学期">
                            <el-option
                                v-for="item in options1"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed3 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_semester_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed4">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">

                    <el-form-item label="课程属性" prop="feature">
                        <el-select v-model="form.feature" placeholder="请选择课程属性">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed4 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_feature_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog
            width="30%"
            title="查询"
            :visible.sync="dialogFormVisibleed5">
            <div class="form-box">
                <el-form :model="form" :rules="rules" ref="form" label-width="150px">
                    <el-form-item label="任课老师姓名" prop="tname">
                        <el-input v-model="form.tname" placeholder="请输入需要查询的任课老师姓名"></el-input>
                    </el-form-item>
                    <el-form-item style="text-align: center" >
                        <el-button @click="dialogFormVisibleed5 = false" >取 消</el-button>
                        <el-button type="primary" @click="loc_tname_submit(form)">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>

    </div>
</template>

<script>
    import main from "../../main";
    export default {
        data: function(){
            return {
                data:[],
                options:[{value: "必修课", label: "必修课"},{value: "选修课", label: "选修课"}],
                options1:[{value: 1, label: "1"},{value: 2, label: "2"},{value: 3, label: "3"},
                    {value: 4, label: "4"},{value: 5, label: "5"},{value: 6, label: "6"},
                    {value: 7, label: "7"},{value: 8, label: "8"}],
                dialogFormVisibleed:false,
                dialogFormVisibleed1:false,
                dialogFormVisibleed2:false,
                dialogFormVisibleed3:false,
                dialogFormVisibleed4:false,
                dialogFormVisibleed5:false,
                dialogFormVisibleed6:false,
                form:{
                    id: '',
                    cno:'',
                    cname:'',
                    credit:'',
                    semester:'',
                    feature:'',
                    tname:''
                },
                rules:{
                    cname:[
                        {required:true,message:'请输入课程名',trigger:'blur'}
                    ],
                    cno:[
                        {required:true,message:'请输入课程号',trigger:'blur'}
                    ],
                    credit:[
                        {required:true,message:'请输入学分',trigger:'blur'}
                    ],
                    semester:[
                        {required:true,message:'请输入学期',trigger:'blur'}
                    ],
                    feature:[
                        {required:true,message:'请设置课程属性',trigger:'blur'}
                    ],
                    tname:[
                        {required:true,message:'请输入任课老师姓名',trigger:'blur'}
                    ]
                }
            }
        },
        created(){
            if(localStorage.getItem('username')===""){
                this.$router.replace('/login')
            }else{this.init();}
        },
        methods:{
            init(){
                this.$http.post(main.url+"/course/list",
                    {},
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                );
            },
            openedit(row){ //修改信息，按钮按下后
                this.dialogFormVisibleed=true;
                this.form={
                    id: row.id,
                    cno: row.cno,
                    cname: row.cname,
                    credit: row.credit,
                    semester: row.semester,
                    feature: row.feature,
                    tname: row.tname
                };
            },
            submit(form){ //修改，提交
                this.$http.post(main.url+"/course/update",
                    {
                        'id': this.form.id,
                        'cno': this.form.cno,
                        'cname': this.form.cname,
                        'credit': this.form.credit,
                        'semester': this.form.semester,
                        'feature': this.form.feature,
                        'tname': this.form.tname
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=> {
                        this.$message({type: 'success', message: '修改成功'});
                        this.form={
                            id: '',
                            cno: '',
                            cname:'',
                            credit:'',
                            semester:'',
                            feature:'',
                            tname:''
                        };
                        this.dialogFormVisibleed = false;
                        this.init();
                    }
                )
            },
            loc_cname(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed2=true;
                this.form={
                    cname :''
                };
            },
            loc_cname_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/course/loc_cname",
                    {
                        'cname': this.form.cname
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed2=false;
            },
            loc_cno(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed6=true;
                this.form={
                    cno :''
                };
            },
            loc_cno_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/course/loc_cno",
                    {
                        'cno': this.form.cno
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed6=false;
            },
            loc_semester(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed3=true;
                this.form={
                    semester :''
                };
            },
            loc_semester_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/course/loc_semester",
                    {
                        'semester': this.form.semester
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed3=false;
            },
            loc_feature(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed4=true;
                this.form={
                    feature :''
                };
            },
            loc_feature_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/course/loc_feature",
                    {
                        'feature': this.form.feature
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed4=false;
            },
            loc_tname(){ //通过学号查询学生信息，按钮按下后
                this.dialogFormVisibleed5=true;
                this.form={
                    tname :''
                };
            },
            loc_tname_submit(){ //通过学号查询学生信息，按钮按下后
                this.$http.post(main.url+"/course/loc_tname",
                    {
                        'tname': this.form.tname
                    },
                    {
                        headers: {'Content-Type':'application/x-www-form-urlencoded'},
                        emulateJSON: true
                    }).then(
                    success=>{
                        this.data=success.data;
                    }
                )
                this.dialogFormVisibleed5=false;
            },
            addmessage(){this.dialogFormVisibleed1=true},
            addnew(form){ //添加成绩信息
                if(this.form.cname==="")
                    this.$message({type: 'error', message: '课程名不能为空！'});
                else if(this.form.credit==="")
                    this.$message({type: 'error', message: '学分不能为空！'});
                else if(this.form.cno==="")
                    this.$message({type: 'error', message: '课程号不能为空！'});
                else if(this.form.semester==="")
                    this.$message({type: 'error', message: '学期不能为空！'});
                else if(this.form.feature==="")
                    this.$message({type: 'error', message: '课程属性不能为空！'});
                else if(this.form.tname==="")
                    this.$message({type: 'error', message: '任课老师姓名不能为空！'});
                else{
                    this.$http.post(main.url+"/course/add",
                        {
                            'cname': this.form.cname,
                            'cno': this.form.cno,
                            'credit': this.form.credit,
                            'semester': this.form.semester,
                            'feature': this.form.feature,
                            'tname': this.form.tname
                        },
                        {
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            emulateJSON: true
                        }).then(
                        success => {
                            this.$message({type: 'success', message: '添加成功'});
                            this.form = {
                                cname: '',
                                cno: '',
                                credit:'',
                                semester:'',
                                feature:'',
                                tname:''
                            };
                            this.init();
                        }
                    );
                    this.dialogFormVisibleed1 = false;
                }
            },
            del_stu(row){ //删除课程
                this.$confirm('请确认是否要删除该课程！', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.post(main.url+"/course/del",
                        {'id': row.id,},
                        {
                            headers: {'Content-Type':'application/x-www-form-urlencoded'},
                            emulateJSON: true
                        }).then(
                        success=> {
                            this.$message({type: 'success', message: '已删除'});
                            this.init();
                        }
                    );
                }).catch(() => {
                    this.$message({type: 'info', message: '已取消'});
                });
            },
        }
    }
</script>
