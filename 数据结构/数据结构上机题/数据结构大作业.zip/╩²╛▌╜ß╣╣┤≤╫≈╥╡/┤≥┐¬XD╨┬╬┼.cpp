//��XD���� 
typedef struct Nnode{
	char Date[20];
	char content[120];
	struct Nnode *next;
}linklist_news;

void Open_XDNews()
{
	int i,num;
	char dat[20],con[120];
	FILE *fp;
	linklist_news *head,*r,*s;
	fp=fopen("XDNews.txt","r");
	head=(linklist_news *)malloc(sizeof(linklist_news));
	r=head;
	for(i=0;i<3;i++)
	{
		if(i==0)
		{
			fscanf(fp,"%s",dat);
			fgets(con,93,fp);
		}
		else if(i==1)
		{
			fscanf(fp,"%s",dat);
			fgets(con,102,fp);
		}
		else
		{
			fscanf(fp,"%s",dat);
			fgets(con,82,fp);
		}
		s=(linklist_news *)malloc(sizeof(linklist_news));
		strcpy(s->Date,dat);
		strcpy(s->content,con);
		r->next=s;
		r=s;
	}
	r->next=NULL;
	fclose(fp);
	printf("\n������������������������������XD���š�������������������������������\n");
	printf("***********************   1 2019-05-18      ************************\n");
	printf("***********************   2 2019-05-20      ************************\n");
	printf("***********************   3 2019-05-21      ************************\n");
	printf("***********************   4 �����������ҳ  ************************\n");
	printf("��������������������������������������������������������������������\n");
	printf("���������ѡ�����뿴�����ţ�"); 
	scanf("%d",&num);
	switch(num)
	{
		case 1: {
			char str1[]={"2019-05-18"};
			linklist_news *p1;
			p1=head->next;
			while((p1!=NULL)&&(strcmp(p1->Date,str1)!=0))
			{
				p1=p1->next;
			}
			printf("Headlines��%s\nDate��%s\n",p1->content,p1->Date);
			printf("  The paper Robust Interpolation of Correspondences for Large Displacement Optical Flow (Robust Matching Interpolation for Large Displacement Optical Flow), published by Hu Yinlin, a doctoral student under the guidance of Professor Li Yunsong of Xidian Telecom, in 2017 at the IEEE Conference on Computer Vision and Pattern Recognition (CVPR), was developed by OpenCV, a fact standard library for industrial image processing and computer vision. Adopt. The algorithm of WEPC is included in OpenCV, which fully embodies the idea of close integration of theoretical research and engineering practice that the Institute of Image Transmission and Processing has been insisting on.\n");
			return Open_XDNews();
			break;
		}
		case 2: {
			char str2[]={"2019-05-20"};
			linklist_news *p2;
			p2=head->next;
			while((p2!=NULL)&&(strcmp(p2->Date,str2)!=0))
			{
				p2=p2->next;
			}
			printf("Headlines��%s\nDate��%s\n",p2->content,p2->Date);
			printf("  Recently, the Shaanxi Provincial Department of Education announced the list of research and training bases for innovation and entrepreneurship education in Shaanxi colleges and universities. After recommendation, declaration and publicity, expert selection and result publication, the West Power Innovation and Entrepreneurship Training Base was approved as the training base for innovation and entrepreneurship in Shaanxi colleges and universities.\n"); 
			return Open_XDNews();
			break;
		}
		case 3: {
			char str3[]={"2019-05-21"};
			linklist_news *p3;
			p3=head->next;
			while((p3!=NULL)&&(strcmp(p3->Date,str3)!=0))
			{
				p3=p3->next;
			}
			printf("Headlines��%s\nDate��%s\n",p3->content,p3->Date);
			printf("  Recently, the Shaanxi Provincial Science and Technology Department issued the announcement for the establishment of Shaanxi Provincial Planned Projects in 2019. West Power has received 176 projects in 2019. A total of 31.28 million yuan was set up for various projects. Compared with previous years, this year's fund and number of projects set up by the school reached a new high, breaking through 30 million yuan for the first time, increasing by 51.3%% and 10%% respectively. Among them, the fund for large projects (key industry innovation chain, science and technology innovation team, etc.) increased by 80.5%% and the number of projects set up increased by 59.1%%.\n");
			return Open_XDNews();
			break;
		}
		case 4: return Open_Browser();break;
		default: {
			printf("ָ����󣡷���ѡ�������������\n");
			return Open_XDNews();
			}
	}
}
