//
//  main.c
//  map guider
//
//  Created by 叶子寻 on 2020/5/25.
//  Copyright © 2020 叶子寻. All rights reserved.
//

#include<stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
#define MAX 60
int M,N;                //N表示顶点数，M表示边数
typedef struct node     //邻接链表结点
{
    int adjvex;         //邻接点域 (表示plan中的下标)
    int length;         //路径长度
    struct node *next;
}edgenode;
typedef struct  //顶点表
{
    char vertex[50];        //顶点域 (存放真正的数值)
    char info[200];         //简介域
    edgenode *link;         //指针域
}vexnode;
vexnode plan[MAX];
int fromwhere[MAX];    //存放顶点1
int towhere[MAX];    //存放顶点2
int weight[MAX];    //存放权重

void get_plan(FILE *fp1,vexnode plan[])  //从文件中读取地图信息
{
    edgenode *s;
    int l;                    //表示下标，无实际意义
    fscanf(fp1,"%d %d",&N,&M);
    fgetc(fp1);
    for(int i=0;i<N;i++)          //顶点的初始化
    {
        fscanf(fp1,"%d %s %s",&l,plan[i].vertex,plan[i].info);  //输入顶点信息
        fgetc(fp1);
        plan[i].link=NULL;          //指针域置NULL
    }
    for(int i=0;i<MAX;i++)  //初始化
    {
        fromwhere[i]=0;
        towhere[i]=0;
        weight[i]=0;
    }
    int i,j,w;                    //i,j分别表示边的两顶点，w为权重
    for(int k=0;k<M;k++)          //建立边表
    {
        fscanf(fp1,"%d %d %d %d",&l,&i,&j,&w);
        fgetc(fp1);
        fromwhere[k]=i;
        towhere[k]=j;
        weight[k]=w;
        
        s=(edgenode*)malloc(sizeof(edgenode));
        s->length=w;
        s->adjvex=j;
        s->next=plan[i].link;
        plan[i].link=s;      //将*s插入顶点vi的边表头部
        
        s=(edgenode*)malloc(sizeof(edgenode));
        s->length=w;
        s->adjvex=i;
        s->next=plan[j].link;
        plan[j].link=s;      //将*s插入顶点vj的边表头部
    }
}

void add_spots(vexnode plan[])//添加景点
{
    printf("请输入要添加的景点名称：");
    scanf("%s",plan[N].vertex);
    printf("请输入要添加的景点信息：");
    scanf("%s",plan[N].info);
    plan[N].link=NULL;
    printf("请输入与新增景点相连的景点序号(输入-1结束)：");
    int spots;
    int road;
    edgenode *s;
    scanf("%d",&spots);
    while(spots<-1||spots>=N)
    {
        printf("输入错误，请重新输入：");
        scanf("%d",&spots);
    }
    while(spots!=-1)
    {
        printf("请输入路径长度：");
        scanf("%d",&road);
        s=(edgenode*)malloc(sizeof(edgenode));
        s->adjvex=spots;
        s->length=road;
        s->next=plan[N].link;
        plan[N].link=s;       //在新节点后插入邻接点信息
        
        s=(edgenode*)malloc(sizeof(edgenode));
        s->adjvex=N;
        s->length=road;
        s->next=plan[spots].link;
        plan[spots].link=s;   //在邻接点后插入新节点信息
        
        fromwhere[M]=N;
        towhere[M]=spots;
        weight[M]=road;
        M++;    //路径数加一
        printf("请输入另一个与新增景点相连的景点序号(输入-1结束)：");
        scanf("%d",&spots);
        while(spots<-1||spots>=N)
        {
            printf("输入错误，请重新输入：");
            scanf("%d",&spots);
        }
    }
    printf("添加景点成功！\n");
    N++;    //点数加一
}

void Dijkstra(int y,int v,vexnode plan[])//寻找从y到v的最短路径
{
    int D[N];             //源点到各点最短距离的数组
    int p[N];             //存放前趋顶点的路径数组
    int s[N];             //是否已找到最短路径的标记数组
    int i,j,k=0,v1,min,max=10000,pre;
    v1=v;
    for(i=0;i<N;i++)      //对各数组初始化
    {
        p[i]=0;
        s[i]=0;
        D[i]=max;
    }
    edgenode *l;
    l=plan[v1].link;
    while(l!=NULL)        //录入源点的到各点的直接距离
    {
        D[l->adjvex]=l->length;
        p[l->adjvex]=v1;
        l=l->next;
    }
    s[v1]=1;              //把源点标记
    for(i=0;i<N;i++)      //求源点到其他各点的最短距离
    {
        min=max+1;
        for(j=0;j<N;j++)
            if((!s[j])&&(D[j]<min))
            {
                min=D[j];
                k=j;      //k用来存储此时的最短点
            }
        s[k]=1;           //k的最短路径已生成
        l=plan[k].link;
        while(l!=NULL)    //调整其他各点的最短路径
        {
            for(j=0;j<N;j++)
                if((j==l->adjvex)&&(!s[j]))
                {
                    if(D[j]>D[k]+l->length)
                    {
                        D[j]=D[k]+l->length;
                        p[j]=k;
                    }
                    break;
                }
            l=l->next;
        }
    }
    //此时由源点v到其他各点的最短路径寻找完毕
    printf("最短路径长度 %d m \t路线： %s",D[y],plan[y].vertex);
    pre=p[y];
    while(pre!=v)
    {
        printf(" -> %s",plan[pre].vertex);
        pre=p[pre];
    }
    printf(" -> %s\n",plan[v].vertex);
}

void print_map()     //打印地图菜单
{
    int k=0,i;       // 计数器
    printf("****************************************\n");
    for(i=0;i<N;i++)
    {
        printf("%d %s  ",i,plan[i].vertex);
        k++;
        if(k==5&&i<N-1)    //分割，便于阅读
        {
            printf("\n\n");
            k=0;
        }
    }
    if(i==N)
        printf("\n");
    printf("****************************************\n");
}

void find_min(vexnode plan[])     //查找最短路径功能
{
    int x,y;   //x为起始点的下标，y为终点下标
    print_map();
    printf("请输入起始点和终点的序号(中间以空格分开)： ");
    scanf("%d %d",&x,&y);
    Dijkstra(x,y,plan);
}

int delete_road(vexnode plan[])      //删除路径
{
    int x,y;    //x为起始点的下标，y为终点下标
    print_map();
    printf("请输入需要删除路径的两个景点的序号(以空格分隔)： ");
    scanf("%d %d",&x,&y);
    edgenode *p,*s;
    p=plan[x].link;
    s=plan[x].link;
    while(p!=NULL)  //在x的指针域中寻找y
    {
        if(p->adjvex == y)//找到了，删掉
        {
            s->next=p->next;
            free(p);
            break;
        }
        s=p;
        p=p->next;
    }
    if(p==NULL) //没找到
    {
        printf("输入错误！这两点之间不存在路径!\n");
        return 0;
    }
    p=plan[y].link;   //找到了，找另一个
    s=plan[y].link;
    while(p!=NULL)  //在y的指针域中寻找x
    {
        if(p->adjvex == x)//找到了，删掉
        {
            s->next=p->next;
            free(p);
            break;
        }
        s=p;
        p=p->next;
    }
    int k=0;    //用于保留删除的位置下标
    for(int i=0;i<M;i++)    //寻找相应的记录
        if((fromwhere[i]==x&&towhere[i]==y)||(fromwhere[i]==y&&towhere[i]==x))
            k=i;
    for(int i=k;i<M-1;i++)  //删除记录
    {
        fromwhere[i]=fromwhere[i+1];
        towhere[i]=towhere[i+1];
        weight[i]=weight[i+1];
    }
    M--;      //路径数减一
    printf("路径删除成功！\n");
    return 1;
}

int change_road(vexnode plan[])   //路径长度更新
{
    int x,y,w;
    print_map();
    printf("请输入需要更改路径长度的两个景点的序号(以空格分隔)： ");
    scanf("%d %d",&x,&y);
    printf("请输入最新的路径长度：");
    scanf("%d",&w);
    edgenode *p;
    p=plan[x].link;
    while(p!=NULL)  //在x的指针域中寻找y
    {
        if(p->adjvex == y)  //找到了，修改
        {
            p->length=w;
            break;
        }
        p=p->next;
    }
    if(p==NULL) //没找到
    {
        printf("输入错误！这两点之间不存在路径!\n");
        return 0;
    }
    else    //找另一个
    {
        p=plan[y].link;
        while(p!=NULL)
        {
            if(p->adjvex == x)//找到了，修改
            {
                p->length=w;
                break;
            }
            p=p->next;
        }
    }
    int k=0;    //用于记录要修改的下标
    for(int i=0;i<M;i++)
        if((fromwhere[i]==x&&towhere[i]==y)||(fromwhere[i]==y&&towhere[i]==x))
            k=i;
    weight[k]=w;
    printf("路径长度更新成功！\n");
    return 1;
}

void find_spots(vexnode plan[])          //查询景点信息
{
    int x;
    print_map();
    printf("请输入需要查询的景点序号： ");
    scanf("%d",&x);
    printf("%s: %s\n",plan[x].vertex,plan[x].info);
}

void change_spots(vexnode plan[])      //修正景点信息
{
    int x;
    char name[50];
    char infor[200];
    print_map();
    printf("请输入需要修改更新的景点序号： ");
    scanf("%d",&x);
    printf("请输入更改后的名称(无需更改请输入'#'退出)：");
    scanf("%s",name);
    if(name[0]!='#')
        strcpy(plan[x].vertex,name);
    printf("请输入更改后的简介(无需更改请输入'#'退出)：");
    scanf("%s",infor);
    if(infor[0]!='#')
        strcpy(plan[x].info,infor);
    printf("修正更新操作完成\n");
}

void save_map(vexnode plan[])    //将现有更新信息存入文件
{
    FILE *fp3;
    fp3=fopen("map2.txt","w");
    fprintf(fp3,"%d %d",N,M);
    for(int i=0;i<N;i++)         //顶点的初始化
    {
        fputc('\n',fp3);
        fprintf(fp3,"%d %s %s",i,plan[i].vertex,plan[i].info);  //输入顶点信息
    }
    fputc('\n',fp3);
    for(int k=0;k<M;k++)
    {
        fprintf(fp3,"%d %d %d %d",k,fromwhere[k],towhere[k],weight[k]);
        if(k==M-1)   break;
        fputc('\n',fp3);
    }
    fclose(fp3);
    remove("map.txt");
    rename("map2.txt","map.txt");//将原文件删除，并将生成文件命名为原文件
}

void add_road(vexnode plan[])   //新增边路径
{
    int x,y,w;
    print_map();
    printf("请输入需要新增路径的两个景点的序号(以空格分隔)： ");
    scanf("%d %d",&x,&y);
    printf("请输入路径长度：");
    scanf("%d",&w);
    edgenode *s;
    s=(edgenode*)malloc(sizeof(edgenode));
    s->adjvex=y;
    s->length=w;
    s->next=plan[x].link;
    plan[x].link=s;
    s=(edgenode*)malloc(sizeof(edgenode));
    s->length=w;
    s->adjvex=x;
    s->next=plan[y].link;
    plan[y].link=s;
    fromwhere[M]=x;
    towhere[M]=y;
    weight[M]=w;
    M++;             //路径数加一
    printf("路径新增成功！\n");
}

void print_user_bar()
{
    printf("\n********MENU********\n");
    printf("0：退出程序\n");
    printf("1：查询最短路径\n");
    printf("2：查询景点信息\n");
    printf("********************\n");
    printf("请输入您的选择：");
}

void user()                       //普通用户使用函数
{
    int x;
    print_user_bar();
    scanf("%d",&x);
    while(x)
    {
        switch (x)
        {
            case 0:return;
            case 1:find_min(plan);break;//查询路径
            case 2:find_spots(plan);break;//查找景点的信息
            default:printf("错误！请重新输入!\n");
        }
        print_user_bar();
        scanf("%d",&x);
    }
}

void print_adm_bar()
{
    printf("\n********MENU********\n");
    printf("0：退出程序\n");
    printf("1：查询最短路径\n");
    printf("2：查询景点信息\n");
    printf("3：修改景点信息\n");
    printf("4：删除路径\n");
    printf("5：新增路径\n");
    printf("6：修改路径长度\n");
    printf("7：新增景点\n");
    printf("8：修改密码\n");
    printf("********************\n");
    printf("请输入您的选择:");
}

void change_code()      //修改密码
{
    FILE *code_new;
    char code_input1[20],code_input2[20];
    printf("这里是修改密码操作!\n");
    printf("请输入新的密码(小于20位)：");
    scanf("%s",code_input1);
    printf("请再次输入新密码：");
    scanf("%s",code_input2);
    if(strcmp(code_input1,code_input2)==0)
    {
        code_new=fopen("code_new.txt","w");
        fprintf(code_new,"%s",code_input1);
        remove("code.txt");  //将原文件删除
        rename("code_new.txt","code.txt"); //将存放最新数据的文件命名该成原来的，以便下一次操作
        printf("密码修改成功！\n");
    }
    else
        printf("两次密码不一致！\n");
}

void administrator()                   //管理员使用函数
{
    int x;
    print_adm_bar();
    scanf("%d",&x);
    while(x)
    {
        switch (x)
        {
            case 1:find_min(plan);break;//查询路径
            case 2:find_spots(plan);break;//查询景点信息
            case 3:change_spots(plan);break;//修改更新景点！
            case 4:delete_road(plan);break;//删除路径！
            case 5:add_road(plan);break;//新增路径
            case 6:change_road(plan);break;//修改路径长度
            case 7:add_spots(plan);break;//新增景点
            case 8:change_code();break;//修改密码
            default:printf("错误！请重新输入!\n");
        }
        print_adm_bar();
        scanf("%d",&x);
    }
    save_map(plan);               //及时保存至信息文件中（文件更新）
}

int verify()        //验证登录
{
    FILE *fp2;
    char code_input[20],code_a[20];
    int power=0,times;
    fp2=fopen("code.txt","r");
    fscanf(fp2,"%s",code_a);   //从文件获取真实密码
    fclose(fp2);
    for(times=5;times>0;times--) //输入密码
    {
        printf("请输入登录密码:");
        scanf("%s",code_input);
        if(strcmp(code_input,code_a)==0)//输入密码与文件中密码相同，登录成功
        {
            power=1;
            printf("登录成功！\n");
            break;
        }
        else
        {
            if(times==1)
                printf("登录失败！\n");  //5次登录失败，退出程序
            else
                printf("密码错误！剩余%d次机会\n",times-1);
        }
    }
    return power;   //power=0登录失败，否则成功
}

int main()
{
    int m;                 //运行时的用户选择
    FILE *fp1;
    fp1=fopen("map.txt","r");
    if(!fp1)
    {
        printf("cannot open the file!\n");
        exit(0);
    }
    get_plan(fp1,plan);
    fclose(fp1);
    printf("**************************** \n ");
    printf("欢 迎 来 到 导 航 查 询 系 统 ！\n");
    printf("****************************\n");
    printf("输入0：退出程序\n");
    printf("输入1：普通用户查询\n");
    printf("输入2：以管理员的身份登录系统\n");
    printf("请输入您的选择：");
    scanf("%d",&m);
    while(m)
    {
        switch (m)
        {
            case 1:user();m=0;break;
            case 2:
            {
                int i;
                i=verify();
                if(i==1)
                {
                    administrator();     //以管理员身份登录系统
                    m=0;
                    break;
                }
                if(i==0)
                    return 0;
            }
            default:printf("错误！请重新输入!\n");
        }
        if(m)
            scanf("%d",&m);
    }
    printf("感谢您的使用！谢谢！\n");
    return 0;
}
